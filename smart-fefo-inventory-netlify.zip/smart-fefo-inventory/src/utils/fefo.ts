import { InventoryBatch, InventoryItem } from '../types';

export interface FEFOValidationResult {
  isValid: boolean;
  violationType: 'LATER_EXPIRY_EXISTS' | 'NONE';
  scannedBatchInfo?: {
    lot: string;
    expiryDate: string;
  };
  earliestBatchInfo?: {
    lot: string;
    expiryDate: string;
    quantity: number;
  };
}

/**
 * Validates if the scanned batch is indeed the oldest/nearest expiring batch for that SKU in stock.
 * If there is a batch that expires earlier, it returns a FEFO violation state.
 */
export function validateFEFOStockOut(
  batches: InventoryBatch[],
  sku: string,
  scannedLot: string,
  scannedExpiry: string
): FEFOValidationResult {
  // 1. Get all active batches for this SKU that have quantity > 0
  const activeBatches = batches.filter(
    b => b.sku.toUpperCase() === sku.toUpperCase() && b.quantity > 0
  );

  if (activeBatches.length <= 1) {
    // If 0 or 1 batch exists in stock, FEFO is trivially valid
    return { isValid: true, violationType: 'NONE' };
  }

  // 2. Sort batches by expiryDate ascending
  const sortedBatches = [...activeBatches].sort((a, b) => {
    return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
  });

  const earliestBatch = sortedBatches[0];

  // 3. Compare scanned batch with the earliest batch
  // If the scanned lot differs and expires strictly after the earliest batch, it's a violation!
  if (
    scannedLot.toUpperCase() !== earliestBatch.lot.toUpperCase() &&
    new Date(scannedExpiry).getTime() > new Date(earliestBatch.expiryDate).getTime()
  ) {
    return {
      isValid: false,
      violationType: 'LATER_EXPIRY_EXISTS',
      scannedBatchInfo: {
        lot: scannedLot,
        expiryDate: scannedExpiry,
      },
      earliestBatchInfo: {
        lot: earliestBatch.lot,
        expiryDate: earliestBatch.expiryDate,
        quantity: earliestBatch.quantity,
      },
    };
  }

  return { isValid: true, violationType: 'NONE' };
}

/**
 * Helper to determine the color styling and label tags for an expiry date
 */
export function getExpiryStatus(expiryDateStr: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(expiryDateStr);
  expiry.setHours(0, 0, 0, 0);

  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return {
      status: 'EXPIRED' as const,
      daysLeft: diffDays,
      label: 'Expired',
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300',
      textClass: 'text-rose-600',
      progressColor: 'bg-rose-500',
    };
  } else if (diffDays <= 30) {
    return {
      status: 'CRITICAL' as const,
      daysLeft: diffDays,
      label: `Expires in ${diffDays}d`,
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse',
      textClass: 'text-amber-600 font-semibold',
      progressColor: 'bg-amber-500',
    };
  } else if (diffDays <= 90) {
    return {
      status: 'WARNING' as const,
      daysLeft: diffDays,
      label: `Expires in ${diffDays}d`,
      badgeClass: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      textClass: 'text-yellow-600',
      progressColor: 'bg-yellow-400',
    };
  } else {
    return {
      status: 'SAFE' as const,
      daysLeft: diffDays,
      label: `${Math.round(diffDays / 30)} months left`,
      badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      textClass: 'text-emerald-600',
      progressColor: 'bg-emerald-500',
    };
  }
}

/**
 * Groups raw batches to represent structured Product stock levels
 */
export function computeInventoryLevels(batches: InventoryBatch[]): InventoryItem[] {
  const itemMap: Record<string, { name: string; batches: InventoryBatch[] }> = {};

  batches.forEach(batch => {
    const skuKey = batch.sku.toUpperCase();
    if (!itemMap[skuKey]) {
      itemMap[skuKey] = {
        name: batch.name,
        batches: [],
      };
    }
    itemMap[skuKey].batches.push(batch);
  });

  return Object.entries(itemMap).map(([sku, data]) => {
    const totalQuantity = data.batches.reduce((sum, b) => sum + b.quantity, 0);
    // Sort batches under this product by expiry date ascending
    const sortedBatches = [...data.batches].sort((a, b) => {
      return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
    });

    return {
      sku,
      name: data.name,
      totalQuantity,
      batches: sortedBatches,
    };
  });
}
