import { useState } from 'react';
import { MovementLog } from '../types';
import { RefreshCw, ClipboardList, TrendingDown, TrendingUp, AlertTriangle, Trash2, Calendar, Download, Check, X } from 'lucide-react';

interface MovementLogsProps {
  logs: MovementLog[];
  onClearLogs?: () => void;
}

export default function MovementLogs({ logs, onClearLogs }: MovementLogsProps) {
  const [filterType, setFilterType] = useState<'ALL' | 'STOCK_IN' | 'STOCK_OUT' | 'STOCK_OUT_OVERRIDE' | 'WASTE'>('ALL');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL'); // 'ALL' or 'YYYY-MM'
  const [confirmClear, setConfirmClear] = useState(false);

  // Core standard CSV downloader helper
  const downloadCSV = (title: string, headers: string[], rows: string[][]) => {
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
      + [
          headers.join(","),
          ...rows.map(e => e.map(val => {
            const cleanVal = String(val === undefined || val === null ? "" : val).replace(/"/g, '""');
            return `"${cleanVal}"`;
          }).join(","))
        ].join("\n");
        
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute("download", `${title.toLowerCase().replace(/\s+/g, '_')}_${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportMonth = (type: 'STOCK_IN' | 'STOCK_OUT') => {
    // Filter logs for selected month
    const monthLogs = logs.filter(log => {
      if (selectedMonth !== 'ALL') {
        const logDate = new Date(log.timestamp);
        const yyyy = logDate.getFullYear();
        const mm = String(logDate.getMonth() + 1).padStart(2, '0');
        const logMonth = `${yyyy}-${mm}`;
        if (logMonth !== selectedMonth) return false;
      }
      return true;
    }).filter(log => {
      if (type === 'STOCK_IN') {
        return log.type === 'STOCK_IN';
      } else {
        return log.type === 'STOCK_OUT' || log.type === 'STOCK_OUT_OVERRIDE' || log.type === 'WASTE';
      }
    });

    const monthLabel = selectedMonth === 'ALL' ? 'all_time' : selectedMonth;
    
    if (type === 'STOCK_IN') {
      const headers = ["Log ID", "Date Time", "SKU", "Product Name", "Lot ID", "Expiry Date", "Quantity Added", "SOP Receipt Notes"];
      const rows = monthLogs.map(l => [
        l.id,
        l.timestamp ? new Date(l.timestamp).toLocaleString() : "",
        l.sku,
        l.name,
        l.lot,
        l.expiryDate,
        String(l.quantity),
        l.notes || ""
      ]);
      downloadCSV(`Stock_In_${monthLabel}`, headers, rows);
    } else {
      const headers = ["Log ID", "Date Time", "Check-Out Action", "SKU", "Product Name", "Lot ID", "Expiry Date", "Quantity Dispatched", "SOP Bypass Notes"];
      const rows = monthLogs.map(l => [
        l.id,
        l.timestamp ? new Date(l.timestamp).toLocaleString() : "",
        l.type,
        l.sku,
        l.name,
        l.lot,
        l.expiryDate,
        String(l.quantity),
        l.notes || ""
      ]);
      downloadCSV(`Stock_Out_${monthLabel}`, headers, rows);
    }
  };

  // Get available months dynamically present in logs (e.g. "2026-06", "2026-05")
  const getAvailableMonths = () => {
    const monthsSet = new Set<string>();
    // Pre-seed current month to guarantee select visibility
    monthsSet.add('2026-06');
    logs.forEach(log => {
      if (log.timestamp) {
        try {
          const d = new Date(log.timestamp);
          if (!isNaN(d.getTime())) {
            const yyyy = d.getFullYear();
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            monthsSet.add(`${yyyy}-${mm}`);
          }
        } catch(e) {}
      }
    });
    return Array.from(monthsSet).sort((a, b) => b.localeCompare(a));
  };

  const filteredLogs = logs
    .filter(log => filterType === 'ALL' || log.type === filterType)
    .filter(log => {
      if (selectedMonth === 'ALL') return true;
      if (!log.timestamp) return false;
      try {
        const d = new Date(log.timestamp);
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        return `${yyyy}-${mm}` === selectedMonth;
      } catch (e) {
        return false;
      }
    })
    // Show newest first
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const getLogBadge = (type: MovementLog['type']) => {
    switch (type) {
      case 'STOCK_IN':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-blue-50/60 text-blue-900 border border-blue-150 px-2 py-0.5 rounded-lg font-bold">
            <TrendingUp className="w-3 h-3 text-blue-600" />
            Stock In
          </span>
        );
      case 'STOCK_OUT':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-slate-50 text-slate-800 border border-slate-250 px-2 py-0.5 rounded-lg font-bold">
            <TrendingDown className="w-3 h-3 text-slate-600" />
            Stock Out
          </span>
        );
      case 'STOCK_OUT_OVERRIDE':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-amber-50 text-amber-800 border border-amber-300 px-2 py-0.5 rounded-lg font-bold animate-pulse">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            FEFO Override
          </span>
        );
      case 'WASTE':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-rose-50 text-rose-800 border border-rose-220 px-2 py-0.5 rounded-lg font-bold">
            <Trash2 className="w-3 h-3 text-rose-600" />
            Disposal/Waste
          </span>
        );
    }
  };

  const formatTimestamp = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' ' + 
             date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch (e) {
      return isoString;
    }
  };

  return (
    <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] overflow-hidden">
      {/* Header and Controls */}
      <div className="bg-slate-900 text-white px-5 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h3 className="text-sm font-extrabold flex items-center gap-2 uppercase tracking-wide">
            <ClipboardList className="w-4.5 h-4.5 text-blue-400" />
            Inventory Movement &amp; Audits
          </h3>
          <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
            Real-time compliance tracing, stock adjustments, and human-override alerts.
          </p>
        </div>

        {onClearLogs && logs.length > 0 && (
          <div className="flex items-center gap-2">
            {!confirmClear ? (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="text-[10px] font-bold text-rose-400 hover:text-white hover:bg-rose-950/40 border border-rose-900/65 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer uppercase tracking-wider"
              >
                Clear History
              </button>
            ) : (
              <div className="flex items-center gap-1 bg-slate-800 p-1.5 rounded-lg border border-slate-700 animate-slideDown whitespace-nowrap">
                <span className="text-[9px] text-rose-300 font-extrabold px-1.5 select-none font-sans mr-1">Proceed?</span>
                <button
                  type="button"
                  onClick={() => {
                    onClearLogs();
                    setConfirmClear(false);
                  }}
                  className="bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-[9px] px-2.5 py-1 rounded cursor-pointer uppercase leading-none"
                >
                  Yes
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="bg-slate-705 hover:bg-slate-700 text-slate-350 hover:text-white font-bold text-[9px] px-2.5 py-1 rounded cursor-pointer leading-none"
                >
                  No
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Monthly Audit Selector & Export Centre */}
      <div className="bg-slate-50 border-b border-slate-100 p-4 space-y-3 shadow-3xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider font-sans whitespace-nowrap select-none">
              Audit Month:
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => {
                setSelectedMonth(e.target.value);
                setConfirmClear(false);
              }}
              className="text-xs bg-white border border-slate-200 rounded-lg p-1.5 font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer min-w-[130px]"
            >
              <option value="ALL">All Months</option>
              {getAvailableMonths().map(m => {
                const [yyyy, mm] = m.split('-');
                const monthNames = [
                  "January", "February", "March", "April", "May", "June", 
                  "July", "August", "September", "October", "November", "December"
                ];
                const monthName = monthNames[parseInt(mm) - 1] || mm;
                return (
                  <option key={m} value={m}>
                    {monthName} {yyyy}
                  </option>
                );
              })}
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleExportMonth('STOCK_IN')}
              disabled={logs.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-100 disabled:opacity-40 text-slate-700 hover:text-slate-900 border border-slate-205 hover:border-slate-300 rounded-lg text-[9px] font-extrabold tracking-wider uppercase cursor-pointer transition-all bg-white"
            >
              <Download className="w-3 h-3 text-blue-600" />
              Export Stock-In {selectedMonth !== 'ALL' ? `(${selectedMonth})` : ''}
            </button>
            <button
              type="button"
              onClick={() => handleExportMonth('STOCK_OUT')}
              disabled={logs.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-slate-100 disabled:opacity-40 text-slate-700 hover:text-slate-900 border border-slate-205 hover:border-slate-300 rounded-lg text-[9px] font-extrabold tracking-wider uppercase cursor-pointer transition-all bg-white"
            >
              <Download className="w-3 h-3 text-rose-600" />
              Export Stock-Out {selectedMonth !== 'ALL' ? `(${selectedMonth})` : ''}
            </button>
          </div>
        </div>
        <p className="text-[9px] text-slate-500 font-semibold leading-relaxed">
          Select a particular month to narrow the clinical log below or compile spreadsheet records specifically for that timeframe.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex border-b border-slate-100 p-2 overflow-x-auto bg-[#f8fafc] gap-1">
        {(['ALL', 'STOCK_IN', 'STOCK_OUT', 'STOCK_OUT_OVERRIDE', 'WASTE'] as const).map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all capitalize whitespace-nowrap cursor-pointer ${
              filterType === type
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200/55'
                : 'text-slate-505 hover:text-slate-800'
            }`}
          >
            {type === 'ALL' ? 'All Activities' : type === 'STOCK_OUT_OVERRIDE' ? 'FEFO Overrides' : type.replace('_', ' ').toLowerCase()}
          </button>
        ))}
      </div>

      {/* Logs Listing */}
      {filteredLogs.length === 0 ? (
        <div className="p-8 text-center bg-white">
          <Calendar className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h4 className="text-slate-900 font-bold text-xs">No activity logged</h4>
          <p className="text-[10px] text-slate-400 font-medium mt-1">
            Logs materialize as soon as you perform stock actions, scans, or adjustments.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-100 bg-white max-h-[480px] overflow-y-auto">
          {filteredLogs.map(log => (
            <div 
              key={log.id} 
              className={`p-4 transition-colors ${
                log.type === 'STOCK_OUT_OVERRIDE' ? 'bg-amber-50/40 hover:bg-amber-50/70' : 'hover:bg-slate-50/40'
              }`}
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                {/* Left block: Log status and item identity */}
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    {getLogBadge(log.type)}
                    <span className="font-mono text-[10px] text-slate-400 font-bold">
                      {formatTimestamp(log.timestamp)}
                    </span>
                  </div>
                  
                  <h4 className="text-xs font-bold text-slate-900 font-sans leading-snug">
                    {log.name}
                  </h4>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] font-medium text-slate-450">
                    <span className="font-mono text-blue-600 font-extrabold uppercase">{log.sku}</span>
                    <span className="text-slate-300">•</span>
                    <span className="bg-slate-50 border border-slate-200 px-1.5 py-0.2 rounded-md font-extrabold font-mono text-slate-700">Lot: {log.lot}</span>
                    <span className="text-slate-300">•</span>
                    <span className="font-mono">Exp: {log.expiryDate}</span>
                  </div>
                </div>

                {/* Right block: Log adjustments */}
                <div className="text-right flex sm:flex-col items-center sm:items-end justify-between sm:justify-center w-full sm:w-auto border-t sm:border-0 border-slate-100 pt-2 sm:pt-0">
                  <span className="text-[10px] text-slate-450 font-medium block sm:hidden">Adjustment:</span>
                  <span className={`text-sm font-mono font-extrabold px-2.5 py-0.5 rounded-lg border ${
                    log.type === 'STOCK_IN' 
                      ? 'bg-blue-50/80 text-blue-700 border-blue-105' 
                      : log.type === 'WASTE' 
                      ? 'bg-rose-50 text-rose-700 border-rose-100'
                      : 'bg-slate-50 text-slate-900 border-slate-200'
                  }`}>
                    {log.type === 'STOCK_IN' ? '+' : '-'}{log.quantity}
                  </span>
                </div>
              </div>

              {/* Warnings Notes if available */}
              {log.notes && (
                <div className={`mt-2 p-2.5 rounded-lg text-[10px] border leading-relaxed font-semibold ${
                  log.type === 'STOCK_OUT_OVERRIDE'
                    ? 'bg-amber-100/60 border-amber-200 text-amber-900'
                    : 'bg-slate-50 border-slate-200 text-slate-650'
                }`}>
                  <p className="flex items-start gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <span>{log.notes}</span>
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
