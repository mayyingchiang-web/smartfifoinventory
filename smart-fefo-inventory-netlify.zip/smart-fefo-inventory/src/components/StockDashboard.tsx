import React, { useState } from 'react';
import { InventoryBatch, InventoryItem, MovementLog, ProductProfile } from '../types';
import { 
  Search, 
  AlertTriangle, 
  Calendar, 
  Package, 
  Trash2, 
  ArrowDownRight, 
  ArrowUpRight, 
  Printer, 
  X, 
  CheckCircle,
  ChevronDown,
  ChevronUp,
  Download,
  Check
} from 'lucide-react';
import { getExpiryStatus, computeInventoryLevels } from '../utils/fefo';
import { QRCodeSVG } from 'qrcode.react';

interface StockDashboardProps {
  batches: InventoryBatch[];
  onDisposeBatch: (batchId: string) => void;
  onUpdateBatch?: (batchId: string, updatedFields: Partial<InventoryBatch>) => void;
  safetyStocks?: Record<string, number>;
  onUpdateSafetyStock?: (sku: string, value: number) => void;
  logs?: MovementLog[];
  productProfiles?: ProductProfile[];
}

export default function StockDashboard({ 
  batches, 
  onDisposeBatch, 
  onUpdateBatch,
  safetyStocks = {},
  onUpdateSafetyStock,
  logs = [],
  productProfiles = []
}: StockDashboardProps) {
  const getSkuUnitsPerBox = (sku: string): number => {
    const profile = productProfiles.find(p => p.sku.toUpperCase() === sku.toUpperCase());
    return profile?.unitsPerBox || 10;
  };
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'LOW_STOCK' | 'EXPIRED' | 'CRITICAL' | 'SAFE'>('ALL');
  
  // Collapsible tracking of SKU batch expansion
  const [expandedSkus, setExpandedSkus] = useState<Record<string, boolean>>({});

  // Track specific thermal label being printed inside dashboard
  const [labelToPrint, setLabelToPrint] = useState<{
    id?: string;
    sku: string;
    name: string;
    lot: string;
    exp: string;
    quantity?: number;
    printQty?: number;
    qrString: string;
    allSeparated?: Array<{ labelId: string; itemIndex: number; totalItems: number; qrString: string }>;
    selectedStickerIndex?: number;
  } | null>(null);

  // SST updating state and form modal
  const [sstTargetBatch, setSstTargetBatch] = useState<InventoryBatch | null>(null);
  const [sstFormStatus, setSstFormStatus] = useState<'NOT_REQUIRED' | 'PENDING' | 'PASSED'>('PENDING');
  const [sstCompletedDate, setSstCompletedDate] = useState('');

  const handleSstBadgeClick = (batch: InventoryBatch) => {
    setSstTargetBatch(batch);
    setSstFormStatus(
      !batch.sstRequired 
        ? 'NOT_REQUIRED' 
        : batch.sstPassed 
          ? 'PASSED' 
          : 'PENDING'
    );
    setSstCompletedDate(batch.sstCompletedDate || new Date().toISOString().split('T')[0]);
  };

  const handleSaveSstStatus = () => {
    if (!sstTargetBatch || !onUpdateBatch) return;

    if (sstFormStatus === 'NOT_REQUIRED') {
      onUpdateBatch(sstTargetBatch.id, {
        sstRequired: false,
        sstPassed: false,
        sstCompletedDate: undefined
      });
    } else if (sstFormStatus === 'PENDING') {
      onUpdateBatch(sstTargetBatch.id, {
        sstRequired: true,
        sstPassed: false,
        sstCompletedDate: undefined
      });
    } else if (sstFormStatus === 'PASSED') {
      onUpdateBatch(sstTargetBatch.id, {
        sstRequired: true,
        sstPassed: true,
        sstCompletedDate: sstCompletedDate || new Date().toISOString().split('T')[0]
      });
    }
    setSstTargetBatch(null);
  };

  const items = computeInventoryLevels(batches);

  // CSV Downloader core function
  const downloadCSV = (title: string, headers: string[], rows: string[][]) => {
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
      + [
          headers.join(","),
          ...rows.map(e => e.map(val => {
            const cleanVal = String(val === undefined || val === null ? "" : val).replace(/"/g, '""');
            return `"${cleanVal}"`;
          }).join(","))
        ].join("\n");
        
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    const dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute("download", `${title.toLowerCase().replace(/\s+/g, '_')}_${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportDashboard = () => {
    const headers = ["SKU", "Product Name", "Available Boxes", "Safety Stock Threshold", "Status / Needs Reorder"];
    const rows = items.map(item => {
      const threshold = safetyStocks[item.sku] !== undefined ? safetyStocks[item.sku] : 5;
      const status = item.totalQuantity <= threshold ? "LOW STOCK (Reorder Suggested)" : "Adequate Stock Level";
      return [
        item.sku,
        item.name,
        String(item.totalQuantity),
        String(threshold),
        status
      ];
    });
    downloadCSV("Laboratory_Stock_Dashboard", headers, rows);
  };

  const handleExportStockIn = () => {
    const headers = ["SKU", "Product Name", "Lot ID", "Expiry Date", "Box Quantity", "Created Date", "SST Protection", "SST Passed/Cleared", "SST Completed Date"];
    const rows = batches.map(b => {
      return [
        b.sku,
        b.name,
        b.lot,
        b.expiryDate,
        String(b.quantity),
        b.createdAt ? b.createdAt.split('T')[0] : "",
        b.sstRequired ? "Required" : "No",
        b.sstPassed ? "PASSED/CLEARED" : (b.sstRequired ? "PENDING LOCK" : "EXEMPT"),
        b.sstCompletedDate || ""
      ];
    });
    downloadCSV("Laboratory_Stock_In_List", headers, rows);
  };

  const handleExportStockOut = () => {
    const headers = ["Log ID", "SOP Action Date/Time", "Movement Action", "SKU Identifier", "Product Name", "Lot ID", "Expiry Date Date", "Quantity Dispatched", "SOP Audit & Bypass Notes"];
    const stockOutLogs = logs.filter(l => l.type === 'STOCK_OUT' || l.type === 'STOCK_OUT_OVERRIDE' || l.type === 'WASTE');
    
    const rows = stockOutLogs.map(l => {
      return [
        l.id,
        l.timestamp ? new Date(l.timestamp).toLocaleString() : "",
        l.type,
        l.sku,
        l.name,
        l.lot,
        l.expiryDate,
        String(l.quantity),
        l.notes || ""
      ];
    });
    downloadCSV("Laboratory_Stock_Out_List", headers, rows);
  };

  // Calculate Metrics
  const activeBatches = batches.filter(b => b.quantity > 0);
  const totalUnits = activeBatches.reduce((sum, b) => sum + b.quantity, 0);
  const totalIndividualItems = activeBatches.reduce((sum, b) => {
    return sum + (b.quantity * getSkuUnitsPerBox(b.sku));
  }, 0);
  
  const totalBoxes = activeBatches.reduce((sum, b) => {
    return sum + (b.quantity / getSkuUnitsPerBox(b.sku));
  }, 0);
  const formattedTotalBoxes = Math.round(totalBoxes * 100) / 100;
  
  const expiredBatches = activeBatches.filter(b => {
    const status = getExpiryStatus(b.expiryDate).status;
    return status === 'EXPIRED';
  });

  const criticalBatches = activeBatches.filter(b => {
    const status = getExpiryStatus(b.expiryDate).status;
    return status === 'CRITICAL';
  });

  const lowStockItems = items.filter(item => {
    const threshold = safetyStocks[item.sku] !== undefined ? safetyStocks[item.sku] : 5;
    return item.totalQuantity <= threshold;
  });

  const sstPendingBatches = activeBatches.filter(b => b.sstRequired && !b.sstPassed);

  // Filter Items & Batches
  const filteredItems = items
    .map(item => {
      // Filter individual batches inside the item based on search criteria
      const filteredBatches = item.batches.filter(batch => {
        if (batch.quantity <= 0) return false;
        
        const matchesSearch = 
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
          batch.lot.toLowerCase().includes(searchTerm.toLowerCase());

        if (!matchesSearch) return false;

        const statusInfo = getExpiryStatus(batch.expiryDate);
        if (filterStatus === 'ALL') return true;
        if (filterStatus === 'EXPIRED') return statusInfo.status === 'EXPIRED';
        if (filterStatus === 'CRITICAL') return statusInfo.status === 'CRITICAL';
        if (filterStatus === 'SAFE') return statusInfo.status === 'SAFE' || statusInfo.status === 'WARNING';
        if (filterStatus === 'LOW_STOCK') return true; // evaluated at the item level below
        
        return true;
      });

      const totalQuantity = filteredBatches.reduce((sum, b) => sum + b.quantity, 0);

      return {
        ...item,
        batches: filteredBatches,
        totalQuantity
      };
    })
    .filter(item => {
      if (item.batches.length === 0) return false;
      if (filterStatus === 'LOW_STOCK') {
        const threshold = safetyStocks[item.sku] !== undefined ? safetyStocks[item.sku] : 5;
        return item.totalQuantity <= threshold;
      }
      return true;
    });

  const toggleExpand = (sku: string) => {
    setExpandedSkus(prev => ({ ...prev, [sku]: !prev[sku] }));
  };

  const expandAll = () => {
    const rec: Record<string, boolean> = {};
    filteredItems.forEach(item => {
      rec[item.sku] = true;
    });
    setExpandedSkus(rec);
  };

  const collapseAll = () => {
    setExpandedSkus({});
  };

  return (
    <div className="space-y-5 animate-fadedIn">
      {/* Dynamic Key Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total SKUs */}
        <div className="bg-white border border-slate-200/80 p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Products</span>
            <div className="bg-slate-100 p-1 rounded-md text-slate-600">
              <Package className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className="text-xl font-extrabold text-slate-900 font-sans tracking-tight">{items.length}</h4>
            <p className="text-[9px] text-slate-400 font-medium">registered SKUs</p>
          </div>
        </div>

        {/* Total Units */}
        <div className="bg-white border border-slate-200/80 p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Boxes</span>
            <div className="bg-blue-50 p-1.5 rounded-lg text-blue-600">
              <span className="text-[10px] font-black font-mono">QTY</span>
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className="text-xl font-extrabold text-slate-900 font-sans tracking-tight">
              {totalUnits} Box{totalUnits !== 1 ? 'es' : ''}
            </h4>
            <p className="text-[9px] text-slate-400 font-semibold mt-0.5 leading-snug">
              ({totalIndividualItems.toLocaleString()} items)
            </p>
          </div>
        </div>

        {/* Low Stock Items Alert Card */}
        <div className={`border p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between transition-colors ${
          lowStockItems.length > 0 ? "bg-rose-50/60 border-rose-200 text-rose-900" : "bg-white border-slate-200/80"
        }`}>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Low Stock SKUs</span>
            <div className={`p-1 rounded-md ${lowStockItems.length > 0 ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-400"}`}>
              <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className={`text-xl font-extrabold font-sans tracking-tight ${lowStockItems.length > 0 ? "text-rose-700 font-black" : "text-slate-900"}`}>
              {lowStockItems.length}
            </h4>
            <p className="text-[9px] text-slate-400 font-medium text-slate-500">below safety stock thresh</p>
          </div>
        </div>

        {/* Expired Batches */}
        <div className={`border p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between transition-colors ${
          expiredBatches.length > 0 ? "bg-rose-50/60 border-rose-200 text-rose-900" : "bg-white border-slate-200/80"
        }`}>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Expired Lots</span>
            <div className={`p-1 rounded-md ${expiredBatches.length > 0 ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-400"}`}>
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className={`text-xl font-extrabold font-sans tracking-tight ${expiredBatches.length > 0 ? "text-rose-700 animate-pulse" : "text-slate-900"}`}>
              {expiredBatches.length}
            </h4>
            <p className="text-[9px] text-slate-400 font-medium">immediate action needed</p>
          </div>
        </div>

        {/* Expiring Soon */}
        <div className={`border p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between transition-colors ${
          criticalBatches.length > 0 ? "bg-amber-50/60 border-amber-200 text-amber-900" : "bg-white border-slate-200/80"
        }`}>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-550 uppercase tracking-wider font-sans">Expiring &lt;30d</span>
            <div className={`p-1 rounded-md ${criticalBatches.length > 0 ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-400"}`}>
              <Calendar className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className={`text-xl font-extrabold font-sans tracking-tight ${criticalBatches.length > 0 ? "text-amber-700 animate-pulse" : "text-slate-900"}`}>
              {criticalBatches.length}
            </h4>
            <p className="text-[9px] text-slate-400 font-medium">FEFO dispatch queue</p>
          </div>
        </div>

        {/* Pending SST */}
        <div className={`border p-3.5 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] relative overflow-hidden flex flex-col justify-between transition-colors ${
          sstPendingBatches.length > 0 ? "bg-amber-50/60 border-amber-200 text-amber-900" : "bg-white border-slate-200/80"
        }`}>
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Pending SST</span>
            <div className={`p-1 rounded-md ${sstPendingBatches.length > 0 ? "bg-amber-105 text-amber-750 font-bold" : "bg-slate-100 text-slate-400"}`}>
              🧪
            </div>
          </div>
          <div className="mt-2.5">
            <h4 className={`text-xl font-extrabold font-sans tracking-tight ${sstPendingBatches.length > 0 ? "text-amber-700 animate-pulse" : "text-slate-900"}`}>
              {sstPendingBatches.length}
            </h4>
            <p className="text-[9px] text-slate-400 font-medium">unpassed safety tests</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200/80 p-4 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search input field */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-[12px] h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by SKU, Product Name, or Lot..."
              className="w-full text-xs pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-[#f8fafc] text-slate-800 font-semibold"
            />
          </div>

          {/* Quick status tabs filter */}
          <div className="flex bg-[#f1f5f9] p-0.5 rounded-xl border border-slate-200 overflow-x-auto scrollbar-none">
            {(['ALL', 'LOW_STOCK', 'EXPIRED', 'CRITICAL', 'SAFE'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`flex-1 text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all capitalize whitespace-nowrap cursor-pointer ${
                  filterStatus === status
                    ? 'bg-white text-slate-900 shadow-xs border border-slate-200/50'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {status === 'LOW_STOCK' 
                  ? '⚠️ Low Stock' 
                  : status === 'CRITICAL' 
                    ? 'Expiring <30d' 
                    : status === 'SAFE' 
                      ? 'Safe Expiry' 
                      : status.toLowerCase()
                }
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stock Levels Section header with expansion controls */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pl-1">
          <h3 className="text-xs font-bold text-slate-550 uppercase tracking-widest font-sans">
            Real-time Laboratory Stock Levels
          </h3>
          <div className="flex items-center gap-1.5">
            <button
              onClick={expandAll}
              className="text-[10px] font-extrabold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200/80 px-2 py-1 rounded-md transition-colors cursor-pointer"
            >
              Expand All Lots
            </button>
            <button
              onClick={collapseAll}
              className="text-[10px] font-extrabold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200/80 px-2 py-1 rounded-md transition-colors cursor-pointer"
            >
              Collapse All
            </button>
          </div>
        </div>

        {filteredItems.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
            <Package className="w-8 h-8 text-slate-300 mx-auto mb-2.5" />
            <h4 className="text-slate-900 font-bold text-xs font-sans">No items match your filters</h4>
            <p className="text-xs text-slate-450 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms, modifying your expiry filters, or scanning new stock.
            </p>
          </div>
        ) : (
          <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200/60 bg-slate-50/50 text-[10px] uppercase font-bold text-slate-500 select-none tracking-wider">
                    <th className="py-3 px-4 font-bold">Product / SKU</th>
                    <th className="py-3 px-4 text-center font-bold">Alert Status</th>
                    <th className="py-3 px-4 text-right font-bold">Total Stock</th>
                    <th className="py-3 px-4 text-center font-bold">Safety Level</th>
                    <th className="py-3 px-4 text-center font-bold">Active Batches</th>
                    <th className="py-3 px-4 text-right pr-6 font-bold">Expansion</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredItems.map(item => {
                    const safetyThreshold = safetyStocks[item.sku] !== undefined ? safetyStocks[item.sku] : 5;
                    const isLowStock = item.totalQuantity <= safetyThreshold;
                    const isExpanded = !!expandedSkus[item.sku];

                    return (
                      <React.Fragment key={item.sku}>
                        <tr 
                          className="hover:bg-slate-50/60 transition-colors cursor-pointer"
                          onClick={() => toggleExpand(item.sku)}
                        >
                          {/* Product Details Columns */}
                          <td className="py-4 px-4 min-w-[220px]">
                            <div className="flex flex-col gap-0.5" onClick={(e) => e.stopPropagation()}>
                              <span className="font-mono text-[9px] font-extrabold text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded-md inline-block w-fit">
                                {item.sku}
                              </span>
                              <span className="text-xs font-extrabold text-slate-900 leading-tight tracking-tight pt-1">
                                {item.name}
                              </span>
                            </div>
                          </td>

                          {/* Status Badge */}
                          <td className="py-4 px-4 text-center whitespace-nowrap">
                            {isLowStock ? (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-extrabold bg-rose-50 text-rose-700 border border-rose-200/80 animate-pulse">
                                <AlertTriangle className="w-3 h-3 text-rose-500" />
                                Low Stock (≤{safetyThreshold})
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200/80">
                                <CheckCircle className="w-3 h-3 text-emerald-500" />
                                Sufficient
                              </span>
                            )}
                          </td>

                          {/* Total Stock Quantity */}
                          <td className="py-4 px-4 text-right whitespace-nowrap">
                            <div className="flex flex-col items-end">
                              <span className={`font-mono text-xs font-black px-2.5 py-1 rounded-lg border ${
                                isLowStock 
                                  ? 'bg-rose-50 border-rose-200 text-rose-800' 
                                  : 'bg-slate-50 border-slate-200/80 text-slate-850'
                              }`}>
                                {item.totalQuantity} Box{item.totalQuantity !== 1 ? 'es' : ''}
                              </span>
                              {(() => {
                                const uPerB = getSkuUnitsPerBox(item.sku);
                                const totalPcs = item.totalQuantity * uPerB;
                                return (
                                  <span className="text-[10px] font-bold text-slate-500 mt-1">
                                    {totalPcs} individual items
                                  </span>
                                );
                              })()}
                            </div>
                          </td>

                          {/* Interactive Safety Threshold configure widget */}
                          <td className="py-4 px-4" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  if (onUpdateSafetyStock) {
                                    onUpdateSafetyStock(item.sku, Math.max(0, safetyThreshold - 1));
                                  }
                                }}
                                className="w-6 h-6 border border-slate-250 bg-white hover:bg-slate-100 rounded-md flex items-center justify-center font-black text-slate-600 hover:text-slate-950 transition-colors text-xs cursor-pointer select-none"
                                title="Decrease Safety Threshold"
                              >
                                -
                              </button>
                              <span className="font-mono text-xs font-black text-slate-900 w-8 text-center select-none">
                                {safetyThreshold}
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  if (onUpdateSafetyStock) {
                                    onUpdateSafetyStock(item.sku, safetyThreshold + 1);
                                  }
                                }}
                                className="w-6 h-6 border border-slate-250 bg-white hover:bg-slate-100 rounded-md flex items-center justify-center font-black text-slate-600 hover:text-slate-955 transition-colors text-xs cursor-pointer select-none"
                                title="Increase Safety Threshold"
                              >
                                +
                              </button>
                            </div>
                          </td>

                          {/* Active Lots summary count */}
                          <td className="py-4 px-4 text-center whitespace-nowrap">
                            <span className="text-[10px] font-bold bg-slate-105 border border-slate-200 text-slate-600 px-2 py-1 rounded-md">
                              {item.batches.length} Lot{item.batches.length !== 1 ? 's' : ''}
                            </span>
                          </td>

                          {/* Expansion toggle button */}
                          <td className="py-4 px-4 text-right pr-6 whitespace-nowrap">
                            <button
                              type="button"
                              className="text-[10px] font-extrabold text-blue-600 hover:text-blue-800 flex items-center gap-1 ml-auto cursor-pointer"
                            >
                              {isExpanded ? (
                                <>
                                  Hide Lots <ChevronUp className="w-3.5 h-3.5" />
                                </>
                              ) : (
                                <>
                                  View Lots <ChevronDown className="w-3.5 h-3.5" />
                                </>
                              )}
                            </button>
                          </td>
                        </tr>

                        {/* Collapsible details layout container */}
                        {isExpanded && (
                          <tr className="bg-slate-50/50">
                            <td colSpan={6} className="py-3 px-4 border-t border-b border-dashed border-slate-200">
                              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs my-1">
                                <div className="bg-slate-50/60 p-3 border-b border-slate-150 flex items-center gap-2">
                                  <Package className="w-3.5 h-3.5 text-blue-500" />
                                  <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-600">
                                    Individual Batch Breakdown (FEFO compliance sequence)
                                  </span>
                                </div>
                                
                                <div className="overflow-x-auto">
                                  <table className="w-full text-left border-collapse text-xs">
                                    <thead>
                                      <tr className="bg-slate-50/30 border-b border-slate-100 text-[10px] uppercase font-bold text-slate-400 select-none">
                                        <th className="py-2.5 px-4 font-bold">Lot Number</th>
                                        <th className="py-2.5 px-4 font-bold">Expiry &amp; Countdown State</th>
                                        <th className="py-2.5 px-4 font-bold text-center">Sperm Survival Safety (SST)</th>
                                        <th className="py-2.5 px-4 font-bold text-right">Batch Qty</th>
                                        <th className="py-2.5 px-4 font-bold text-right pr-4">Actions</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100 bg-white animate-fadedIn">
                                      {item.batches.map(batch => {
                                        const expiry = getExpiryStatus(batch.expiryDate);

                                        return (
                                          <tr key={batch.id} className="hover:bg-slate-50/30 transition-colors">
                                            {/* Lot number */}
                                            <td className="py-3 px-4 font-mono font-bold text-slate-700">
                                              <span className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-md">
                                                Lot {batch.lot}
                                              </span>
                                            </td>

                                            {/* Expiry Details */}
                                            <td className="py-3 px-4">
                                              <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-1.5">
                                                  <span className={`text-[9px] font-bold border px-2 py-0.2 rounded-full ${expiry.badgeClass}`}>
                                                    {expiry.label}
                                                  </span>
                                                  <span className={`font-mono font-semibold ${expiry.textClass}`}>
                                                    {batch.expiryDate}
                                                  </span>
                                                </div>
                                                {/* Countdown progress line */}
                                                <div className="w-[110px] bg-slate-100 h-1 rounded-full overflow-hidden mt-0.5">
                                                  <div 
                                                    className={`h-full ${expiry.progressColor}`}
                                                    style={{ width: `${Math.max(5, Math.min(100, (expiry.daysLeft / 365) * 100))}%` }}
                                                  />
                                                </div>
                                              </div>
                                            </td>

                                            {/* Clickable Status SST Badge */}
                                            <td className="py-3 px-4 text-center">
                                              <span
                                                onClick={() => handleSstBadgeClick(batch)}
                                                title="Click to update SST test status and completion date"
                                                className={`text-[9px] font-extrabold border px-2 py-1 rounded-full cursor-pointer inline-flex items-center gap-1 select-none transition-all ${
                                                  !batch.sstRequired
                                                    ? 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100 hover:text-slate-700'
                                                    : batch.sstPassed 
                                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100' 
                                                      : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100 animate-pulse'
                                                }`}
                                              >
                                                🧪 SST: {!batch.sstRequired ? 'Not Required' : batch.sstPassed ? `Passed (${batch.sstCompletedDate || 'Done'})` : 'Pending'}
                                              </span>
                                            </td>

                                            {/* Quantity */}
                                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-850 whitespace-nowrap">
                                              <div>{batch.quantity} Box{batch.quantity !== 1 ? 'es' : ''}</div>
                                              <div className="text-[10px] font-medium text-slate-400 mt-0.5">
                                                ({batch.quantity * getSkuUnitsPerBox(batch.sku)} individual items)
                                              </div>
                                            </td>

                                            {/* Action tools */}
                                            <td className="py-3 px-4 text-right pr-4">
                                              <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                                                {/* Labels Printer Trigger */}
                                                <button
                                                  type="button"
                                                  onClick={() => {
                                                    const qty = batch.quantity;
                                                    const separatedStickers: Array<{ labelId: string; itemIndex: number; totalItems: number; qrString: string }> = [];
                                                    const printCount = qty > 0 ? qty : 1;
                                                    for (let i = 1; i <= printCount; i++) {
                                                      const labelId = `${batch.id}-item-${i}`;
                                                      separatedStickers.push({
                                                        labelId,
                                                        itemIndex: i,
                                                        totalItems: printCount,
                                                        qrString: JSON.stringify({
                                                          sku: batch.sku,
                                                          name: batch.name,
                                                          lot: batch.lot,
                                                          exp: batch.expiryDate,
                                                          type: 'FEFO_LABEL',
                                                          labelId,
                                                          itemIndex: i,
                                                          totalItems: printCount
                                                        })
                                                      });
                                                    }

                                                    setLabelToPrint({
                                                      id: batch.id,
                                                      sku: batch.sku,
                                                      name: batch.name,
                                                      lot: batch.lot,
                                                      exp: batch.expiryDate,
                                                      quantity: qty,
                                                      qrString: separatedStickers[0]?.qrString || JSON.stringify({
                                                        sku: batch.sku,
                                                        name: batch.name,
                                                        lot: batch.lot,
                                                        exp: batch.expiryDate,
                                                        type: 'FEFO_LABEL'
                                                      }),
                                                      allSeparated: separatedStickers,
                                                      selectedStickerIndex: 0
                                                    });
                                                  }}
                                                  className="p-1 hover:bg-slate-105 text-slate-500 hover:text-slate-800 rounded border border-slate-200 transition-colors cursor-pointer inline-flex items-center gap-1"
                                                  title="Print thermo barcode"
                                                >
                                                  <Printer className="w-3 h-3" />
                                                  <span className="text-[10px] font-bold">Print</span>
                                                </button>

                                                {/* Cargo waste / disposal action button */}
                                                {expiry.status === 'EXPIRED' ? (
                                                  <button
                                                    type="button"
                                                    onClick={() => onDisposeBatch(batch.id)}
                                                    className="p-1 px-2.5 bg-rose-50 border border-rose-200 hover:bg-rose-100 text-rose-700 font-bold text-[10px] rounded transition-colors flex items-center gap-1 cursor-pointer"
                                                    title="Dispose Expired Batch"
                                                  >
                                                    <Trash2 className="w-3 h-3 text-rose-600" />
                                                    Dispose
                                                  </button>
                                                ) : (
                                                  <button
                                                    type="button"
                                                    onClick={() => onDisposeBatch(batch.id)}
                                                    className="p-1.5 text-slate-400 hover:text-rose-650 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                                                    title="Dispose Cargo Batch"
                                                  >
                                                    <Trash2 className="w-3 h-3" />
                                                  </button>
                                                )}
                                              </div>
                                            </td>
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* 📥 Excel/CSV Export and Clinical Backups Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div>
          <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5 font-sans">
            <Download className="w-4 h-4 text-blue-600" />
            Clinical Audit &amp; Spreadsheet Export Center
          </h4>
          <p className="text-[11px] text-slate-500 mt-1 leading-normal">
            Export raw laboratory inventory records, active storage batches, or historical checkout dispatches for regulatory compliance tracking, offline Excel analysis, or safety audits.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Card 1: Dashboard */}
          <button
            type="button"
            onClick={handleExportDashboard}
            className="flex items-center justify-between p-3.5 border border-slate-150 rounded-xl hover:bg-blue-50/40 hover:border-blue-200 transition-all text-left bg-slate-50/50 group cursor-pointer"
          >
            <div className="min-w-0 pr-2">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Overall Stock</span>
              <span className="block text-xs font-extrabold text-slate-850 mt-1.5 leading-none">Stock Dashboard</span>
              <span className="block text-[9px] text-slate-400 mt-1 truncate">Current levels & safety stocks</span>
            </div>
            <div className="bg-white p-1.5 rounded-lg border border-slate-150 text-slate-550 group-hover:text-blue-600 group-hover:border-blue-200 shadow-3xs transition-all">
              <Download className="w-3.5 h-3.5" />
            </div>
          </button>

          {/* Card 2: Stock In */}
          <button
            type="button"
            onClick={handleExportStockIn}
            className="flex items-center justify-between p-3.5 border border-slate-150 rounded-xl hover:bg-blue-50/40 hover:border-blue-200 transition-all text-left bg-slate-50/50 group cursor-pointer"
          >
            <div className="min-w-0 pr-2">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none font-sans">Active Batches</span>
              <span className="block text-xs font-extrabold text-slate-850 mt-1.5 leading-none">Stock-In Batch List</span>
              <span className="block text-[9px] text-slate-400 mt-1 truncate">Lots, expiries & safety test states</span>
            </div>
            <div className="bg-white p-1.5 rounded-lg border border-slate-150 text-slate-550 group-hover:text-blue-600 group-hover:border-blue-200 shadow-3xs transition-all">
              <Download className="w-3.5 h-3.5" />
            </div>
          </button>

          {/* Card 3: Stock Out */}
          <button
            type="button"
            onClick={handleExportStockOut}
            className="flex items-center justify-between p-3.5 border border-slate-150 rounded-xl hover:bg-blue-50/40 hover:border-blue-200 transition-all text-left bg-slate-50/50 group cursor-pointer"
          >
            <div className="min-w-0 pr-2">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none font-sans">checkout history</span>
              <span className="block text-xs font-extrabold text-slate-850 mt-1.5 leading-none">Stock-Out Dispatches</span>
              <span className="block text-[9px] text-slate-400 mt-1 truncate">Dispatched boxes, waste & overrides</span>
            </div>
            <div className="bg-white p-1.5 rounded-lg border border-slate-150 text-slate-550 group-hover:text-blue-600 group-hover:border-blue-200 shadow-3xs transition-all">
              <Download className="w-3.5 h-3.5" />
            </div>
          </button>
        </div>
      </div>

      {/* Dynamic Thermal Label Printing Modal overlay popup */}
      {labelToPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xl w-full max-w-sm overflow-hidden flex flex-col">
            
            {/* Header */}
            <div className="bg-slate-900 text-white px-4 py-3 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Printer className="w-4 h-4 text-blue-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider">Thermal Sticker Preview</h4>
              </div>
              <button 
                onClick={() => setLabelToPrint(null)}
                className="text-slate-450 hover:text-white bg-slate-800 p-1.5 rounded-lg transition-all"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-5 flex-1 space-y-4">
              <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                Standard **50mm x 30mm** thermal label format. Place underneath target package to scan. All barcode/QR codes support local FEFO scanning.
              </p>

              {/* Dynamic QR Unit Differentiation Indicator */}
              {labelToPrint.allSeparated && labelToPrint.allSeparated.length > 1 && (
                <div className="bg-blue-50 border border-blue-100 p-2.5 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-[10px] text-blue-900 leading-normal font-semibold">
                    <span className="flex h-2 w-2 rounded-full bg-blue-500 animate-pulse"></span>
                    <span>Multi-box differentiation scanner active:</span>
                  </div>
                  <p className="text-[9px] text-blue-750 font-normal leading-relaxed">
                    This lot contains <strong>{labelToPrint.allSeparated.length} boxes</strong>. To differentiate individual clinical containers, the system outputs unique sub-tracking IDs to prevent duplicate checkouts. Select a sticker index:
                  </p>
                  
                  <div className="flex flex-wrap gap-1 md:gap-1.5 pt-1">
                    {labelToPrint.allSeparated.map((stick, idx) => (
                      <button
                        key={stick.labelId}
                        type="button"
                        onClick={() => {
                          setLabelToPrint(prev => {
                            if (!prev) return null;
                            return {
                              ...prev,
                              qrString: stick.qrString,
                              selectedStickerIndex: idx
                            };
                          });
                        }}
                        className={`text-[9px] px-2.5 py-1 rounded-md border font-extrabold cursor-pointer transition-all ${
                          labelToPrint.selectedStickerIndex === idx
                            ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                            : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-250'
                        }`}
                      >
                        Sticker #{idx + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Printable Dynamic Thermal Label sticker */}
              <div className="flex justify-center py-2 bg-slate-50 rounded-xl border border-slate-100 p-4">
                <div 
                  id="printable-label-dashboard"
                  className="bg-white border border-slate-950 p-4 rounded-sm shadow-xs text-black font-sans flex flex-row items-center gap-4 w-[280px] h-[150px] overflow-hidden select-none"
                  style={{ printColorAdjust: 'exact' }}
                >
                  {/* Left Column: QR Code */}
                  <div className="bg-white p-1 border border-black/80 flex-shrink-0 flex items-center justify-center">
                    <QRCodeSVG 
                      value={labelToPrint.qrString} 
                      size={86} 
                      level="H" 
                      includeMargin={false}
                    />
                  </div>

                  {/* Right Column: Metadata */}
                  <div className="flex-1 text-left min-w-0 flex flex-col justify-between h-full py-0.5">
                    <div>
                      <div className="text-[9px] uppercase font-mono font-extrabold tracking-wider bg-black text-white px-2 py-0.5 rounded-md inline-block max-w-full truncate mb-1">
                        {labelToPrint.sku}
                      </div>
                      <h4 className="text-[11px] font-black leading-tight text-slate-950 font-sans tracking-tight line-clamp-2 uppercase">
                        {labelToPrint.name}
                      </h4>
                    </div>

                    <div className="space-y-0.5 border-t border-dashed border-black/40 pt-1 mt-1">
                      <div className="flex items-center justify-between text-[9px] font-extrabold font-mono leading-none">
                        <span className="text-slate-655">LOT:</span>
                        <span className="text-slate-950 tracking-wide">{labelToPrint.lot}</span>
                      </div>
                      <div className="flex items-center justify-between text-[9px] font-extrabold font-mono leading-none">
                        <span className="text-slate-655">EXP:</span>
                        <span className="text-rose-850 font-black">{labelToPrint.exp}</span>
                      </div>
                      {labelToPrint.allSeparated && labelToPrint.allSeparated.length > 0 && (
                        <div className="flex items-center justify-between text-[8px] font-black font-sans leading-none text-blue-900 bg-blue-50 border border-blue-200 rounded px-1.5 py-0.5 mt-0.5">
                          <span>STICKER:</span>
                          <span>#{ (labelToPrint.selectedStickerIndex ?? 0) + 1 } of { labelToPrint.allSeparated.length }</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Print Media Style Hack Rule */}
              <style>{`
                @media print {
                  body * {
                    visibility: hidden !important;
                  }
                  #printable-label-dashboard, #printable-label-dashboard * {
                    visibility: visible !important;
                  }
                  #printable-label-dashboard {
                    position: fixed !important;
                    left: 50% !important;
                    top: 55% !important;
                    transform: translate(-50%, -50%) scale(1.6) !important;
                    border: 2px solid black !important;
                    box-shadow: none !important;
                  }
                }
              `}</style>
            </div>

            {/* Footer Buttons */}
            <div className="bg-slate-50 border-t border-slate-100 px-4 py-3 flex gap-2">
              <button
                type="button"
                onClick={() => setLabelToPrint(null)}
                className="flex-1 bg-white border border-slate-200 hover:bg-slate-105 text-slate-700 font-extrabold py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Sticker
              </button>
            </div>

          </div>
        </div>
      )}

      {/* SST Laboratory Status Editor Modal Overlay */}
      {sstTargetBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs select-none">
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-2xl w-full max-w-sm overflow-hidden flex flex-col">
            
            {/* Header */}
            <div className="bg-slate-900 text-white px-4 py-3.5 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-blue-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider">Update SST Laboratory Status</h4>
              </div>
              <button 
                onClick={() => setSstTargetBatch(null)}
                className="text-slate-400 hover:text-white bg-slate-800 p-1.5 rounded-lg transition-all"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="p-5 flex-1 space-y-4">
              <div className="bg-slate-50 border border-slate-200/50 p-3 rounded-xl">
                <span className="block font-mono text-[9px] font-black text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded w-fit mb-1 leading-none">
                  {sstTargetBatch.sku}
                </span>
                <h5 className="text-xs font-extrabold text-slate-900 leading-tight">
                  {sstTargetBatch.name}
                </h5>
                <p className="text-[10px] text-slate-500 font-medium font-mono mt-1">
                  Lot: Lot {sstTargetBatch.lot} | Expiry: {sstTargetBatch.expiryDate}
                </p>
              </div>

              {/* Status Radio Choices */}
              <div className="space-y-2.5">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Test Progress Selection
                </label>

                {/* Not Required Choice */}
                <label className={`flex items-start gap-3 p-2.5 border rounded-xl cursor-pointer transition-all ${
                  sstFormStatus === 'NOT_REQUIRED' 
                    ? 'bg-slate-50 border-slate-400' 
                    : 'bg-white border-slate-200 hover:bg-slate-50/50'
                }`}>
                  <input 
                    type="radio" 
                    name="sstStatus" 
                    value="NOT_REQUIRED"
                    checked={sstFormStatus === 'NOT_REQUIRED'}
                    onChange={() => setSstFormStatus('NOT_REQUIRED')}
                    className="mt-0.5"
                  />
                  <div>
                    <span className="block text-[11px] font-bold text-slate-800 leading-none">SST Not Required</span>
                    <span className="block text-[9px] text-slate-455 mt-1 leading-normal">
                      This item is exempt from biological capability testing.
                    </span>
                  </div>
                </label>

                {/* Pending Choice */}
                <label className={`flex items-start gap-3 p-2.5 border rounded-xl cursor-pointer transition-all ${
                  sstFormStatus === 'PENDING' 
                    ? 'bg-amber-50/40 border-amber-300' 
                    : 'bg-white border-slate-200 hover:bg-slate-50/50'
                }`}>
                  <input 
                    type="radio" 
                    name="sstStatus" 
                    value="PENDING"
                    checked={sstFormStatus === 'PENDING'}
                    onChange={() => setSstFormStatus('PENDING')}
                    className="mt-0.5"
                  />
                  <div>
                    <span className="block text-[11px] font-bold text-slate-850 leading-none flex items-center gap-1.5">
                      SST Pending Testing <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                    </span>
                    <span className="block text-[9px] text-slate-455 mt-1 leading-normal">
                      Testing required. Lock dispatch until laboratory parameters clear.
                    </span>
                  </div>
                </label>

                {/* Passed Choice */}
                <label className={`flex items-start gap-3 p-2.5 border rounded-xl cursor-pointer transition-all ${
                  sstFormStatus === 'PASSED' 
                    ? 'bg-emerald-50/30 border-emerald-300' 
                    : 'bg-white border-slate-200 hover:bg-slate-50/50'
                }`}>
                  <input 
                    type="radio" 
                    name="sstStatus" 
                    value="PASSED"
                    checked={sstFormStatus === 'PASSED'}
                    onChange={() => setSstFormStatus('PASSED')}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <span className="block text-[11px] font-bold text-slate-850 leading-none">
                      SST Passed &amp; Cleared
                    </span>
                    <span className="block text-[9px] text-slate-455 mt-1 leading-normal">
                      Lab criteria fulfilled. Ready for safe patient container dispatch.
                    </span>
                  </div>
                </label>
              </div>

              {/* Date Finished Input field */}
              {sstFormStatus === 'PASSED' && (
                <div className="space-y-1 animate-fadedIn flex flex-col">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    SST Completion Date
                  </label>
                  <input 
                    type="date"
                    value={sstCompletedDate}
                    onChange={(e) => setSstCompletedDate(e.target.value)}
                    className="w-full text-xs font-mono border border-slate-200 p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                    required
                  />
                </div>
              )}
            </div>

            {/* Footer buttons */}
            <div className="bg-slate-50 border-t border-slate-150 px-4 py-3 flex gap-2">
              <button
                type="button"
                onClick={() => setSstTargetBatch(null)}
                className="flex-1 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-extrabold py-2 rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveSstStatus}
                className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                Save Changes
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
