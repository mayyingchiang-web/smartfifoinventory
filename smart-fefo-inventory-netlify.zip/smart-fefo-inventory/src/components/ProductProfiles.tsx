import React, { useState } from 'react';
import { ProductProfile, InventoryBatch } from '../types';
import { PlusCircle, Trash2, Package, Check, ClipboardList, Info, AlertTriangle, CheckCircle, Edit3, X } from 'lucide-react';

interface ProductProfilesProps {
  profiles: ProductProfile[];
  onAddProfile: (profile: ProductProfile, initialBatch?: { lot: string; expiryDate: string; quantity: number }) => void;
  onDeleteProfile: (sku: string) => void;
  onQuickStockIn: (sku: string) => void;
  onUpdateProfile?: (sku: string, updatedFields: Partial<ProductProfile>) => void;
}

export default function ProductProfiles({
  profiles,
  onAddProfile,
  onDeleteProfile,
  onQuickStockIn,
  onUpdateProfile
}: ProductProfilesProps) {
  // Navigation for tab inside Profiles: LIST vs ADD
  const [activeSubTab, setActiveSubTab] = useState<'LIST' | 'ADD'>('LIST');

  // New Profile Form State
  const [sku, setSku] = useState('');
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [safetyStock, setSafetyStock] = useState(5);
  const [unitsPerBox, setUnitsPerBox] = useState<number>(10);
  const [sstRequired, setSstRequired] = useState(false);

  // Optional Initial Batch State
  const [hasInitialBatch, setHasInitialBatch] = useState(false);
  const [lot, setLot] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Form errors
  const [error, setError] = useState('');

  // Editing Product Profile State
  const [editingProfile, setEditingProfile] = useState<ProductProfile | null>(null);
  const [editName, setEditName] = useState('');
  const [editBrand, setEditBrand] = useState('');
  const [editSafetyStock, setEditSafetyStock] = useState(5);
  const [editUnitsPerBox, setEditUnitsPerBox] = useState<number>(10);
  const [editSstRequired, setEditSstRequired] = useState(false);

  const startEditing = (p: ProductProfile) => {
    setEditingProfile(p);
    setEditName(p.name);
    setEditBrand(p.brand || '');
    setEditSafetyStock(p.safetyStock);
    setEditUnitsPerBox(p.unitsPerBox || 10);
    setEditSstRequired(p.sstRequired);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProfile) return;
    if (onUpdateProfile) {
      onUpdateProfile(editingProfile.sku, {
        name: editName.trim(),
        brand: editBrand.trim(),
        safetyStock: Number(editSafetyStock) || 0,
        unitsPerBox: Number(editUnitsPerBox) || 10,
        sstRequired: editSstRequired
      });
    }
    setEditingProfile(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!sku.trim() || !name.trim()) {
      setError('SKU and Product Name are required.');
      return;
    }

    const cleanSku = sku.trim().toUpperCase();

    // Duplicate SKU check
    if (profiles.some(p => p.sku === cleanSku)) {
      setError(`A product profile for SKU "${cleanSku}" already exists.`);
      return;
    }

    if (hasInitialBatch) {
      if (!lot.trim() || !expiryDate) {
        setError('Please specify Lot Number and Expiry Date for the initial batch.');
        return;
      }
      if (quantity <= 0) {
        setError('Initial quantity must be greater than 0.');
        return;
      }
    }

    // Call add profile
    onAddProfile(
      {
        sku: cleanSku,
        name: name.trim(),
        brand: brand.trim(),
        safetyStock: Number(safetyStock) || 0,
        unitsPerBox: Number(unitsPerBox) || 10,
        sstRequired
      },
      hasInitialBatch ? { lot: lot.trim().toUpperCase(), expiryDate, quantity: Number(quantity) } : undefined
    );

    // Reset Form
    setSku('');
    setName('');
    setBrand('');
    setSafetyStock(5);
    setUnitsPerBox(10);
    setSstRequired(false);
    setHasInitialBatch(false);
    setLot('');
    setExpiryDate('');
    setQuantity(1);

    // Go back to the list
    setActiveSubTab('LIST');
  };

  return (
    <div className="space-y-4 animate-fadedIn">
      {/* Tab Selectors */}
      <div className="flex bg-white border border-slate-200 p-1 rounded-xl shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <button
          onClick={() => setActiveSubTab('LIST')}
          className={`flex-1 flex items-center justify-center gap-2 text-xs font-bold py-2.5 rounded-lg transition-all cursor-pointer ${
            activeSubTab === 'LIST'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          Product Directory ({profiles.length})
        </button>
        <button
          onClick={() => setActiveSubTab('ADD')}
          className={`flex-1 flex items-center justify-center gap-2 text-xs font-bold py-2.5 rounded-lg transition-all cursor-pointer ${
            activeSubTab === 'ADD'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          Pre-Register New Product
        </button>
      </div>

      {activeSubTab === 'LIST' ? (
        <div className="space-y-4">
          <div className="p-3.5 bg-blue-50/60 border border-blue-100 rounded-xl text-xs text-blue-900 flex items-start gap-3 shadow-xs">
            <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold">Registered Product Profiles:</span> Pre-defining product criteria sets default safety stocks, product naming, and biological safety testing (SST) requirements. When a lab assistant stocks in, the system automatically tags new batches correctly without prompting.
            </div>
          </div>

          {profiles.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
              <Package className="w-10 h-10 text-slate-350 mx-auto mb-2.5 animate-pulse" />
              <h4 className="text-slate-900 font-extrabold text-xs">No Pre-Registered Products</h4>
              <p className="text-xs text-slate-450 mt-1.5 max-w-sm mx-auto">
                No custom templates defined yet. Click "Pre-Register New Product" above to catalog your lab's inventory items.
              </p>
            </div>
          ) : (
            <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200/65 bg-slate-50 text-[10px] uppercase font-bold text-slate-500 select-none tracking-wider whitespace-nowrap">
                      <th className="py-3.5 px-4 font-bold">SKU &amp; Product Name</th>
                      <th className="py-3.5 px-3 font-bold">Brand</th>
                      <th className="py-3.5 px-3 text-center font-bold">Items / Box</th>
                      <th className="py-3.5 px-3 text-center font-bold">Safety Stock Threshold</th>
                      <th className="py-3.5 px-3 text-center font-bold">SST Safety Requirement</th>
                      <th className="py-3.5 px-4 text-right font-bold pr-6">Management Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {profiles.map(profile => (
                      <tr key={profile.sku} className="hover:bg-slate-50/40 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex flex-col gap-1">
                            <span className="font-mono text-[9px] font-black tracking-wider text-blue-600 bg-blue-50 border border-blue-100 px-1.5 py-0.5 rounded w-fit">
                              {profile.sku}
                            </span>
                            <span className="text-xs font-black text-slate-900 leading-tight">
                              {profile.name}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-xs font-semibold text-slate-650">
                            {profile.brand || <span className="text-slate-400 font-normal italic">N/A</span>}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-700">
                          <span className="bg-slate-100/80 border border-slate-200 text-slate-800 px-2.5 py-0.5 rounded-full text-[10px]">
                            {profile.unitsPerBox || 10} /box
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-700">
                          {profile.safetyStock} boxes
                        </td>
                        <td className="py-3 px-3 text-center">
                          {profile.sstRequired ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              🧪 SST Required (Pending by default)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold bg-slate-50 text-slate-500 border border-slate-200 w-fit">
                              SST Not Required
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right pr-6">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => onQuickStockIn(profile.sku)}
                              className="px-2.5 py-1 text-[10px] font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors cursor-pointer"
                            >
                              + Stock In
                            </button>
                            <button
                              onClick={() => startEditing(profile)}
                              className="p-1 px-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 hover:border-slate-200 rounded transition-colors border border-transparent cursor-pointer"
                              title="Edit Registry Details"
                            >
                              <Edit3 className="w-3.5 h-3.5 text-blue-500" />
                            </button>
                            <button
                              onClick={() => onDeleteProfile(profile.sku)}
                              className="p-1 px-2 text-slate-400 hover:text-rose-650 hover:bg-rose-50 hover:border-rose-100 rounded transition-colors border border-transparent cursor-pointer"
                              title="Delete Profile Template"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* pre-register form */
        <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-xs max-w-lg mx-auto">
          <div className="bg-slate-900 text-slate-100 px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Package className="w-4.5 h-4.5 text-blue-400" />
              <h3 className="font-bold text-xs uppercase tracking-wider">Catalog New Product Profile</h3>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {error && (
              <div className="bg-rose-50 border border-rose-200 text-xs text-rose-800 p-3 rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                <span className="font-medium">{error}</span>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-wider mb-1">Product SKU</label>
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="e.g. K-MPIP-3130"
                  className="w-full text-xs font-mono border border-slate-200 p-2.5 rounded-lg font-bold focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white uppercase text-slate-800"
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-wider mb-1">Item Brand / Manufacturer</label>
                <input
                  type="text"
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  placeholder="e.g. Vitrolife"
                  className="w-full text-xs border border-slate-200 p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-wider mb-1">Product Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. ICSI Injection Pipette"
                className="w-full text-xs border border-slate-200 p-2.5 rounded-lg font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-wider mb-1">Safety Stock Limit</label>
                <input
                  type="number"
                  value={safetyStock}
                  min={0}
                  onChange={(e) => setSafetyStock(Math.max(0, parseInt(e.target.value) || 0))}
                  placeholder="e.g. 5"
                  className="w-full text-xs font-mono border border-slate-200 p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                  required
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-550 uppercase tracking-wider mb-1">Standard Pack Size (Items / Box)</label>
                <input
                  type="number"
                  value={unitsPerBox}
                  min={1}
                  onChange={(e) => setUnitsPerBox(Math.max(1, parseInt(e.target.value) || 1))}
                  placeholder="e.g. 10"
                  className="w-full text-xs font-mono border border-slate-200 p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-800"
                  required
                />
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200/60 p-3 rounded-xl">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sstRequired}
                  onChange={(e) => setSstRequired(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300 text-slate-900 focus:ring-slate-900 w-4 h-4 cursor-pointer accent-slate-950"
                />
                <div className="flex-1 select-none">
                  <span className="block text-[11px] font-black text-slate-850 leading-tight">
                    🧪 Require Sperm Survival/Suitability Testing (SST)
                  </span>
                  <span className="block text-[9px] text-slate-500 font-medium leading-normal mt-0.5">
                    Flag this product permanently. Newly stocked batches will automatically start as "Pending SST" safety locks.
                  </span>
                </div>
              </label>
            </div>

            <div className="border-t border-slate-100 pt-3.5 space-y-3.5">
              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={hasInitialBatch}
                  onChange={(e) => setHasInitialBatch(e.target.checked)}
                  className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 w-4 h-4 cursor-pointer accent-slate-950"
                />
                <span className="text-[11px] font-black text-slate-850">📦 Stock-In Initial Batch Immediately</span>
              </label>

              {hasInitialBatch && (
                <div className="p-3.5 border border-slate-200/60 bg-slate-50/50 rounded-xl space-y-3 animate-fadedIn">
                  <p className="text-[10px] text-slate-450 font-bold leading-tight">
                    PROVIDE METADATA FOR INITIAL WAREHOUSE BATCH
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] font-bold text-slate-550 uppercase mb-1">Lot / Batch ID</label>
                      <input
                        type="text"
                        value={lot}
                        onChange={(e) => setLot(e.target.value)}
                        placeholder="e.g. LOT-A01"
                        className="w-full text-xs font-mono border border-slate-200 p-2 rounded-lg focus:outline-none bg-white uppercase text-slate-800"
                        required={hasInitialBatch}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-bold text-slate-550 uppercase mb-1">Expiry Date</label>
                      <input
                        type="date"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        className="w-full text-xs font-mono border border-slate-200 p-2 rounded-lg focus:outline-none bg-white text-slate-800"
                        required={hasInitialBatch}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-slate-550 uppercase mb-1">Initial Pack Boxes</label>
                    <input
                      type="number"
                      value={quantity}
                      min={1}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-full text-xs font-mono border border-slate-200 p-2 rounded-lg focus:outline-none bg-white text-slate-800"
                      required={hasInitialBatch}
                    />
                  </div>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 border border-slate-950 font-semibold py-2.5 rounded-lg text-xs text-white hover:bg-slate-800 transition-colors uppercase tracking-wider cursor-pointer mt-2"
            >
              Committed Pre-Register Product
            </button>
          </form>
        </div>
      )}

      {/* Editing Dialog Modal overlay */}
      {editingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-xl overflow-hidden animate-fadedIn">
            <div className="bg-slate-950 text-white px-5 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-blue-400" />
                <h4 className="text-xs font-black uppercase tracking-wider">
                  Edit Registry: {editingProfile.sku}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingProfile(null)}
                className="text-slate-400 hover:text-white rounded transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-4">
              <div>
                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 font-sans">
                  Product SKU Identifier
                </label>
                <input
                  type="text"
                  value={editingProfile.sku}
                  disabled
                  className="w-full text-xs font-mono border border-slate-250 p-2.5 rounded-lg bg-slate-50 text-slate-500 font-extrabold"
                />
              </div>

              <div>
                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 font-sans">
                  Product Profile Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full text-xs border border-slate-250 p-2.5 rounded-lg font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-900"
                  required
                />
              </div>

              <div>
                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 font-sans">
                  Item Brand / Manufacturer
                </label>
                <input
                  type="text"
                  value={editBrand}
                  onChange={(e) => setEditBrand(e.target.value)}
                  className="w-full text-xs border border-slate-250 p-2.5 rounded-lg font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 font-sans">
                    Safety Stock (Boxes)
                  </label>
                  <input
                    type="number"
                    value={editSafetyStock}
                    min={0}
                    onChange={(e) => setEditSafetyStock(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full text-xs border border-slate-250 p-2.5 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 font-sans">
                    Pack Size (Items / Box)
                  </label>
                  <input
                    type="number"
                    value={editUnitsPerBox}
                    min={1}
                    onChange={(e) => setEditUnitsPerBox(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full text-xs border border-slate-250 p-2.5 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white text-slate-900"
                    required
                  />
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editSstRequired}
                    onChange={(e) => setEditSstRequired(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-slate-950 focus:ring-slate-950 w-4 h-4 cursor-pointer accent-slate-950"
                  />
                  <div className="flex-1 select-none">
                    <span className="block text-[11px] font-black text-slate-850 leading-tight">
                      🧪 Require Sperm Survival/Suitability Testing (SST)
                    </span>
                    <span className="block text-[9px] text-slate-500 leading-normal mt-0.5 font-medium">
                      If flagged, newly added batches of this specific SKU are automatically placed on a safety lock until the SST bio-assays pass.
                    </span>
                  </div>
                </label>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingProfile(null)}
                  className="flex-1 bg-white hover:bg-slate-50 border border-slate-250 text-slate-700 font-bold py-2.5 rounded-lg text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-slate-900 hover:bg-slate-800 border border-slate-950 text-white font-bold py-2.5 rounded-lg text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
