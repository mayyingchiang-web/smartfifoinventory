import React, { useState, FormEvent } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Printer, Sparkles, AlertCircle, PlusCircle, CheckCircle } from 'lucide-react';
import { InventoryItem } from '../types';

interface QRGeneratorProps {
  existingItems: InventoryItem[];
  onLabelCreated?: (labelData: { sku: string; name: string; lot: string; exp: string }) => void;
}

export default function QRGenerator({ existingItems, onLabelCreated }: QRGeneratorProps) {
  const [sku, setSku] = useState('');
  const [name, setName] = useState('');
  const [lot, setLot] = useState('');
  const [exp, setExp] = useState('');
  const [qty, setQty] = useState(1);
  const [generatedLabel, setGeneratedLabel] = useState<{
    sku: string;
    name: string;
    lot: string;
    exp: string;
    qrString: string;
  } | null>(null);

  const [notification, setNotification] = useState<string | null>(null);

  // Auto-fill product name if they select an existing SKU
  const handleSkuSelect = (selectedSku: string) => {
    setSku(selectedSku);
    const item = existingItems.find(i => i.sku === selectedSku);
    if (item) {
      setName(item.name);
    }
  };

  const handleGenerateDefaultLot = () => {
    const todayStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    setLot(`L-${todayStr}-${rand}`);
  };

  const handleGenerate = (e: FormEvent) => {
    e.preventDefault();
    if (!sku.trim() || !name.trim() || !lot.trim() || !exp) {
      alert("Please fill in all label fields (SKU, Name, Lot, Expiry Date).");
      return;
    }

    const payload = {
      sku: sku.trim().toUpperCase(),
      name: name.trim(),
      lot: lot.trim().toUpperCase(),
      exp: exp,
      type: 'FEFO_LABEL' as const
    };

    const qrString = JSON.stringify(payload);
    setGeneratedLabel({
      sku: payload.sku,
      name: payload.name,
      lot: payload.lot,
      exp: payload.exp,
      qrString
    });

    setNotification("Label generated successfully! You can scan this mockup or download it.");
    setTimeout(() => setNotification(null), 4000);

    if (onLabelCreated) {
      onLabelCreated({
        sku: payload.sku,
        name: payload.name,
        lot: payload.lot,
        exp: payload.exp
      });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_3px_rgba(0,0,0,0.02)] overflow-hidden max-w-lg mx-auto animate-fadedIn">
      <div className="bg-slate-900 px-6 py-4 text-white">
        <h3 className="text-sm font-extrabold uppercase tracking-wide leading-none flex items-center gap-2">
          <Printer className="w-4.5 h-4.5 text-blue-400" />
          Smart Expiry QR Label Generator
        </h3>
        <p className="text-[11px] text-slate-400 mt-1">
          Capture product details, build lot specifications, and generate standard thermal label prints.
        </p>
      </div>

      <div className="p-6 space-y-6">
        {notification && (
          <div className="bg-blue-50/60 border border-blue-100 text-blue-900 text-xs rounded-lg p-3 flex items-center gap-2.5 shadow-xs">
            <CheckCircle className="w-4 h-4 text-blue-600 flex-shrink-0" />
            <span className="font-semibold">{notification}</span>
          </div>
        )}

        <form onSubmit={handleGenerate} className="space-y-4">
          {/* SKU / Barcode Identifier */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              Product SKU / Base Barcode
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. AMOX-500 or scan original barcode"
                className="flex-1 text-xs px-3 py-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 w-full font-mono bg-white text-slate-800"
                required
              />
              {existingItems.length > 0 && (
                <select
                  onChange={(e) => handleSkuSelect(e.target.value)}
                  value={sku}
                  className="max-w-[125px] text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 text-slate-600 font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 cursor-pointer"
                >
                  <option value="">Quick Prefill</option>
                  {existingItems.map(item => (
                    <option key={item.sku} value={item.sku}>
                      {item.sku}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {/* Product Name */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              Product Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Amoxicillin 500mg Capsule"
              className="w-full text-xs px-3 py-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-semibold bg-white text-slate-800"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Lot Number */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Lot / Batch ID
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={lot}
                  onChange={(e) => setLot(e.target.value)}
                  placeholder="e.g. LOT-A23"
                  className="w-full text-xs px-3 py-2.5 pr-10 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 uppercase font-mono bg-white text-slate-800"
                  required
                />
                <button
                  type="button"
                  onClick={handleGenerateDefaultLot}
                  title="Generate dynamic lot code"
                  className="absolute right-2.5 top-[11px] hover:text-blue-600 text-slate-400 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Expiry Date */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Expiry Date
              </label>
              <input
                type="date"
                value={exp}
                onChange={(e) => setExp(e.target.value)}
                className="w-full text-xs px-3 py-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-mono bg-white text-slate-800"
                required
              />
            </div>
          </div>

          {/* Generate Button */}
          <button
            type="submit"
            className="w-full bg-slate-900 text-white font-semibold py-2.5 rounded-lg text-xs hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 mt-2 shadow-xs cursor-pointer uppercase tracking-wider"
          >
            <PlusCircle className="w-4 h-4 text-blue-400" />
            Generate Expiry QR Label
          </button>
        </form>

        {/* Generated Thermal Label Simulator Printout */}
        {generatedLabel && (
          <div className="border border-slate-200 bg-[#f8fafc] p-4 rounded-xl flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-3">
              Printable Label Preview (Zebra/Brother 5" x 2.5" Standard)
            </span>

            {/* Simulated Label Roll Box (5" x 2.5" landscape aspect ratio) */}
            <div 
              id="printable-label"
              className="bg-white text-black border-2 border-black w-[400px] h-[200px] p-3.5 flex flex-row gap-4 rounded-xs shadow-xs relative print:border-0 print:shadow-none"
            >
              {/* Left Side: QR Code Area */}
              <div className="flex flex-col items-center justify-center bg-slate-50 border border-slate-100 p-2.5 rounded-sm w-[130px] h-full flex-shrink-0">
                <QRCodeSVG 
                  value={generatedLabel.qrString} 
                  size={100} 
                  level="M" 
                  includeMargin={false}
                />
                <span className="text-[7.5px] font-mono text-slate-500 font-extrabold tracking-widest mt-1.5 uppercase leading-none">SCAN COMPLIANCE</span>
              </div>

              {/* Right Side: Clinical Metadata specifications */}
              <div className="flex flex-col justify-between flex-1 h-full min-w-0">
                {/* Header detail */}
                <div className="border-b border-black pb-1.5 flex justify-between items-center">
                  <span className="font-mono text-[9px] font-bold bg-slate-100 px-1 py-0.5 rounded-sm">LOT: {generatedLabel.lot}</span>
                  <span className="font-mono text-[9px] font-extrabold text-red-600 bg-red-50 px-1 py-0.5 rounded-sm">EXP: {generatedLabel.exp}</span>
                </div>

                {/* Central Identity specifications */}
                <div className="my-1.5 min-w-0">
                  <h3 className="font-sans font-extrabold text-[13px] text-slate-900 leading-snug line-clamp-2 select-all mb-0.5 min-w-0 break-words">{generatedLabel.name}</h3>
                  <p className="font-mono text-[10px] font-bold text-slate-700 tracking-wider uppercase select-all leading-none">{generatedLabel.sku}</p>
                </div>

                {/* Bottom quality control footer */}
                <div className="border-t border-dotted border-black/50 pt-1.5 flex justify-between items-center text-[7.5px]">
                  <span className="font-mono text-slate-500 font-bold uppercase tracking-wider leading-none">SMART FEFO VALID</span>
                  <span className="bg-black text-white font-mono font-extrabold px-1.5 py-0.5 rounded-sm leading-none">5" x 2.5" LBL</span>
                </div>
              </div>
            </div>

            {/* Print action buttons */}
            <div className="flex gap-4 w-full max-w-[400px] mt-4">
              <button
                type="button"
                onClick={handlePrint}
                className="flex-1 border border-slate-250 hover:border-slate-350 bg-white text-slate-700 font-bold py-2.5 rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <Printer className="w-4 h-4 text-slate-500" />
                Print Label
              </button>
            </div>
            <p className="text-[10px] text-slate-450 text-center mt-3 leading-relaxed max-w-[360px] font-medium">
              💡 <strong>Mobile tip:</strong> Take a screenshot of this label or print to a Bluetooth portable label maker before sticking it on the stock box!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
