import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Info, CheckCircle, HelpCircle, X } from 'lucide-react';

interface CustomDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  type: 'alert' | 'confirm' | 'prompt';
  value?: string;
  onChangeValue?: (val: string) => void;
  placeholder?: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function CustomDialog({
  isOpen,
  title,
  message,
  type,
  value = '',
  onChangeValue,
  placeholder = 'Type here...',
  confirmText = 'OK',
  cancelText = 'Cancel',
  onConfirm,
  onCancel
}: CustomDialogProps) {
  if (!isOpen) return null;

  // Determine icon and color based on title or type
  const isDanger = title.toLowerCase().includes('delete') || 
                   title.toLowerCase().includes('dispose') || 
                   title.toLowerCase().includes('waste') ||
                   title.toLowerCase().includes('violation');
  const isWarn = title.toLowerCase().includes('warning') || 
                 title.toLowerCase().includes('override') || 
                 title.toLowerCase().includes('caution');

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={type === 'confirm' ? undefined : onCancel}
          className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs"
        />

        {/* Modal Window Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ type: 'spring', duration: 0.35, bounce: 0.15 }}
          className="relative bg-white border border-slate-200/80 rounded-xl shadow-xl w-full max-w-sm overflow-hidden z-10"
        >
          {/* Header Theme Bar */}
          <div className={`h-1.5 w-full ${isDanger ? 'bg-rose-500' : isWarn ? 'bg-amber-500' : 'bg-blue-500'}`} />

          {/* Dialog Content */}
          <div className="p-5">
            <div className="flex gap-3.5">
              {/* Icon */}
              <div className={`p-2.5 rounded-lg h-fit ${
                isDanger ? 'bg-rose-50 text-rose-600' : 
                isWarn ? 'bg-amber-50 text-amber-600' : 
                'bg-blue-50 text-blue-600'
              }`}>
                {isDanger ? (
                  <AlertTriangle className="w-5 h-5 pr-0.5" />
                ) : isWarn ? (
                  <AlertTriangle className="w-5 h-5" />
                ) : type === 'prompt' ? (
                  <HelpCircle className="w-5 h-5" />
                ) : (
                  <Info className="w-5 h-5" />
                )}
              </div>

              {/* Message Details */}
              <div className="flex-1 min-w-0">
                <h3 className="font-extrabold text-sm text-slate-900 leading-snug tracking-tight">
                  {title}
                </h3>
                <p className="mt-1.5 text-[11px] text-slate-500 font-medium leading-relaxed">
                  {message}
                </p>
              </div>
            </div>

            {/* Prompt input field if type is prompt */}
            {type === 'prompt' && onChangeValue && (
              <div className="mt-4">
                <input
                  type="text"
                  value={value}
                  onChange={(e) => onChangeValue(e.target.value)}
                  placeholder={placeholder}
                  className="w-full text-xs px-3 py-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 font-semibold bg-[#f8fafc] text-slate-800"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && value.trim()) {
                      onConfirm();
                    }
                  }}
                />
              </div>
            )}

            {/* Actions Footer button block */}
            <div className="mt-5 flex gap-2 justify-end">
              {type !== 'alert' && (
                <button
                  type="button"
                  onClick={onCancel}
                  className="px-3.5 py-2 hover:bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-800 font-bold text-[11px] rounded-lg transition-all cursor-pointer uppercase tracking-wider"
                >
                  {cancelText}
                </button>
              )}
              <button
                type="button"
                onClick={onConfirm}
                disabled={type === 'prompt' && !value.trim()}
                className={`px-4 py-2 text-white font-extrabold text-[11px] rounded-lg transition-all cursor-pointer uppercase tracking-wider shadow-xs disabled:opacity-50 ${
                  isDanger 
                    ? 'bg-rose-600 hover:bg-rose-700' 
                    : isWarn 
                    ? 'bg-amber-600 hover:bg-amber-700' 
                    : 'bg-slate-900 hover:bg-slate-800'
                }`}
              >
                {confirmText}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
