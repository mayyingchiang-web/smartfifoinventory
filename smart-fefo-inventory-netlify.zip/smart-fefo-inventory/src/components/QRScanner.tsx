import React, { useEffect, useRef, useState, FormEvent } from 'react';
import { Html5Qrcode, Html5QrcodeCameraScanConfig } from 'html5-qrcode';
import { Camera, RefreshCw, AlertTriangle, Play, Pause, Keyboard } from 'lucide-react';

interface QRScannerProps {
  onScan: (decodedText: string) => void;
  title: string;
  subtitle?: string;
  isActive: boolean;
}

export default function QRScanner({ onScan, title, subtitle, isActive }: QRScannerProps) {
  const [scannerId] = useState(() => `reader-${Math.random().toString(36).substr(2, 9)}`);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [showManual, setShowManual] = useState(false);
  
  const qrCodeInstance = useRef<Html5Qrcode | null>(null);

  // Initialize and starting the QR Reader
  useEffect(() => {
    if (!isActive) {
      if (qrCodeInstance.current && qrCodeInstance.current.isScanning) {
        qrCodeInstance.current.stop().then(() => {
          setIsScanning(false);
        }).catch(err => console.error("Error stopping scanner:", err));
      }
      return;
    }

    // Delay start slightly to allow DOM element to render
    const timer = setTimeout(() => {
      const html5Qrcode = new Html5Qrcode(scannerId);
      qrCodeInstance.current = html5Qrcode;

      const config: Html5QrcodeCameraScanConfig = {
        fps: 10,
        qrbox: (width, height) => {
          const minimalDim = Math.min(width, height);
          const qrboxSize = Math.floor(minimalDim * 0.7);
          return { width: qrboxSize, height: qrboxSize };
        },
        aspectRatio: 1.0,
      };

      html5Qrcode.start(
        { facingMode: "environment" },
        config,
        (decodedText) => {
          // Play a gentle beep sound using web audio API to enhance tactile feedback
          playBeep();
          onScan(decodedText);
        },
        (errorMessage) => {
          // Minor scan failures (e.g. frame did not detect code) are normal, suppress verbose logs
        }
      ).then(() => {
        setHasPermission(true);
        setIsScanning(true);
        setErrorMsg(null);
      }).catch((err) => {
        console.warn("Camera start failed gracefully or No physical camera found:", err);
        setHasPermission(false);
        const errStr = String(err?.message || err);
        if (errStr.includes("NotFoundError") || errStr.includes("device not found") || errStr.includes("NotReadableError")) {
          setErrorMsg("No physical camera device was detected on this workspace system. For your convenience, the virtual laboratory barcode simulator below has been automatically unfolded.");
        } else {
          setErrorMsg(`Camera initialization could not be completed (${errStr}). Please approve permissions or use the virtual scanner emulator below.`);
        }
        setShowManual(true);
      });
    }, 150);

    return () => {
      clearTimeout(timer);
      if (qrCodeInstance.current && qrCodeInstance.current.isScanning) {
        qrCodeInstance.current.stop().catch(err => console.error("Cleanup stop failed:", err));
      }
    };
  }, [isActive, scannerId, onScan]);

  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // high pitched clean beep
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.1);
    } catch (e) {
      // Ignored if browser blocks audio
    }
  };

  const handleManualSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) {
      onScan(manualInput.trim());
      setManualInput('');
    }
  };

  // Helper template strings with mockup data for users to test easily
  const fillSampleQR = (skuSymbol: string) => {
    let mockStr = '';
    if (skuSymbol === 'PIPETTE') {
      mockStr = JSON.stringify({
        sku: 'K-MPIP-3130',
        name: 'K-MPIP-3130 - ICSI Injection Pipette',
        lot: 'N212236',
        exp: '2027-12-31',
        type: 'FEFO_LABEL'
      });
    } else if (skuSymbol === 'EXPIRED') {
      mockStr = JSON.stringify({
        sku: 'HEPA-FILTER',
        name: 'HEPA Inline Filter',
        lot: 'EXP-LOT-404',
        exp: '2025-04-10', // Clearly expired (current date is June 1, 2026)
        type: 'FEFO_LABEL'
      });
    } else {
      mockStr = '354013'; // Raw Semen Container SKU scan
    }
    setManualInput(mockStr);
    setShowManual(true);
  };

  if (!isActive) return null;

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-slate-50/50 border border-slate-200/85 rounded-xl shadow-xs max-w-md mx-auto w-full transition-all">
      <div className="w-full text-center mb-3">
        <h3 className="text-xs font-extrabold text-slate-900 flex items-center justify-center gap-2 uppercase tracking-wider">
          <Camera className="w-4 h-4 text-blue-600 animate-pulse" />
          {title}
        </h3>
        {subtitle && <p className="text-[11px] text-slate-400 font-medium mt-0.5">{subtitle}</p>}
      </div>

      {/* Styled Scanning Viewport */}
      <div className="relative w-full aspect-square max-w-[280px] bg-black rounded-lg overflow-hidden shadow-inner border-2 border-slate-900 group">
        <div id={scannerId} className="w-full h-full object-cover"></div>

        {/* Live overlay elements */}
        {isScanning && (
          <>
            {/* Pulsating green scanner frame boundaries */}
            <div className="absolute inset-x-[15%] inset-y-[15%] pointer-events-none">
              {/* Top Left Corner */}
              <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-emerald-500 rounded-tl"></div>
              {/* Top Right Corner */}
              <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-emerald-500 rounded-tr"></div>
              {/* Bottom Left Corner */}
              <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-emerald-500 rounded-bl"></div>
              {/* Bottom Right Corner */}
              <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-emerald-500 rounded-br"></div>
            </div>

            {/* Red Laser Scanning bar animation */}
            <div className="absolute inset-x-[15%] h-0.5 bg-rose-500 shadow-[0_0_8px_2px_rgba(244,63,94,0.6)] top-[15%] animate-[scan_2.5s_ease-in-out_infinite] pointer-events-none"></div>

            {/* Live scanning overlay text */}
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 bg-black/60 backdrop-blur-xs text-emerald-400 text-[10px] font-mono tracking-wider px-2 py-0.5 rounded-full uppercase">
              Align Code in Box
            </div>
          </>
        )}

        {/* Permission and error fallbacks */}
        {hasPermission === false && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 text-slate-300 p-4 text-center">
            <AlertTriangle className="w-10 h-10 text-amber-500 mb-2 animate-bounce" />
            <p className="text-xs font-semibold text-white">Camera Access Blocked</p>
            <p className="text-[10px] text-slate-400 mt-1 px-2 line-clamp-3">
              {errorMsg}
            </p>
          </div>
        )}
      </div>

      {/* Manual Code Emulator (highly valuable for desktop and staging) */}
      <div className="w-full mt-4 border-t border-slate-100 pt-3">
        <button
          type="button"
          onClick={() => setShowManual(p => !p)}
          className="w-full flex items-center justify-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-600 py-1 transition-all uppercase tracking-wider"
        >
          <Keyboard className="w-4 h-4" />
          {showManual ? "Hide Scanner Simulator" : "Can't Scan? Open Simulator"}
        </button>

        {showManual && (
          <div className="mt-2.5 p-3 bg-blue-50/50 border border-blue-100 rounded-lg space-y-2">
            <label className="block text-[10px] font-bold text-blue-900 uppercase tracking-wider">
              Simulated Scanner Input (QR Label / Barcode Text)
            </label>
            <textarea
              value={manualInput}
              onChange={(e) => setManualInput(e.target.value)}
              placeholder='Paste JSON label or enter raw barcode...'
              rows={3}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  if (manualInput.trim()) {
                    onScan(manualInput.trim());
                    setManualInput('');
                  }
                }
              }}
              className="w-full text-xs font-mono p-2 border border-blue-150 rounded-md focus:outline-hidden focus:ring-1 focus:ring-blue-550 focus:border-blue-550 bg-white text-slate-800"
            />
            <div className="flex gap-2 justify-between">
              <div className="flex gap-1.5 overflow-x-auto py-0.5">
                <button
                  type="button"
                  onClick={() => fillSampleQR('PIPETTE')}
                  className="px-2 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-[10px] text-slate-700 font-semibold rounded-md whitespace-nowrap shadow-xs cursor-pointer"
                >
                  🧪 Seed ICSI Pipette (Valid QR)
                </button>
                <button
                  type="button"
                  onClick={() => fillSampleQR('EXPIRED')}
                  className="px-2 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-[10px] text-rose-700 hover:text-white hover:bg-rose-600 border border-rose-200 text-[10px] font-semibold rounded-md whitespace-nowrap shadow-xs cursor-pointer"
                >
                  ⚠️ Seed Expired Filter (Hard Block Demo)
                </button>
                <button
                  type="button"
                  onClick={() => fillSampleQR('BARCODE')}
                  className="px-2 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-[10px] text-slate-700 font-semibold rounded-md whitespace-nowrap shadow-xs cursor-pointer"
                >
                  🏷️ Seed Semen Container SKU
                </button>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (manualInput.trim()) {
                    onScan(manualInput.trim());
                    setManualInput('');
                  }
                }}
                disabled={!manualInput.trim()}
                className="px-3 py-1 bg-slate-900 text-white font-semibold hover:bg-slate-800 rounded-lg text-xs transition-colors shadow-xs disabled:opacity-50 cursor-pointer uppercase tracking-wider text-[10px]"
              >
                Scan Code
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes scan {
          0%, 100% { top: 15%; opacity: 0.8; }
          50% { top: 85%; opacity: 0.8; }
        }
      `}</style>
    </div>
  );
}
